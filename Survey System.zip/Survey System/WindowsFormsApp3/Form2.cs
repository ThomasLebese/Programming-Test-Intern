﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp3
{
    public partial class Form2 : Form
    {
        //string connection
        string path = @"Data Source = DESKTOP-TVCHB79\SQLEXPRESS;Initial Catalog = survey;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        SqlCommand foodTyp;
        SqlCommand activitiesTime;
        string food1;
        string food2;
        string food3;
        string food4;
        string food5;
        string food6;
        int eatOut;
        int watchMovie;
        int watchTV;
        int listenRadio;
        

        public Form2()
        {
            InitializeComponent();
            con = new SqlConnection(path);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textSurname.Text==""||textName.Text =="" || textNumber.Text =="" || textDate.Text ==""||textAge.Text =="")
            {
                MessageBox.Show("Please Fill in the blanks");
            }
            else
            {
                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into person ( person_Name, person_Surname, person_contact_number, person_date, person_Age ) values('" + textSurname.Text + "','" + textName.Text + "','" + textNumber.Text + "','" + textDate.Text + "','" + textAge.Text + "')", con);
                    cmd.ExecuteNonQuery();

                    //we store pizza
                    if (checkBox1.Checked == true)
                    {
                        food1 = "Pizza";
                    }
                    else
                    {
                        food1 = "Null";
                    }

                    //we store pasta
                    if (checkBox2.Checked == true)
                    {
                        food2 = "Pasta";
                    }
                    else
                    {
                        food2 = "Null";
                    }

                    //we store pap and wors 
                    if (checkBox3.Checked == true)
                    {
                        food3 = "pap and wors";
                    }
                    else
                    {
                        food3 = "Null";
                    }

                    //we store Chicken stir fry 
                    if (checkBox4.Checked == true)
                    {
                        food4 = "Chicken stir fry";
                    }
                    else
                    {
                        food4 = "Null";
                    }

                    //we store Beer stir fry
                    if (checkBox5.Checked == true)
                    {
                        food5 = "Beer stir fry";
                    }
                    else
                    {
                        food5 = "Null";
                    }

                    //we store Other 
                    if (checkBox6.Checked == true)
                    {
                        food6 = "Other";
                    }
                    else
                    {
                        food6 = "Null";
                    }

                    //store food to food table
                    foodTyp = new SqlCommand("Insert into food ( food_type1, food_type2,food_type3, food_type4, food_type5, food_type6 ) values('" + food1 +"','" + food2 + "','" + food3 + "','" + food4 + "','" + food5 + "','" + food6 + "')", con);
                    foodTyp.ExecuteNonQuery();

                    //activities 
                    //people who likes to eat out
                    if (radioButton1.Checked == true)
                    {
                        eatOut = 1;
                    }
                    if (radioButton2.Checked == true)
                    {
                        eatOut = 2;
                    }
                    if (radioButton3.Checked == true)
                    {
                        eatOut = 3;
                    }
                    if (radioButton4.Checked == true)
                    {
                        eatOut = 4;
                    }
                    if (radioButton5.Checked == true)
                    {
                        eatOut = 5;
                    }

                    //people who like to watch Movies
                    if (radioButton6.Checked == true)
                    {
                        watchMovie = 1;
                    }
                    if (radioButton7.Checked == true)
                    {
                        watchMovie = 2;
                    }
                    if (radioButton8.Checked == true)
                    {
                        watchMovie = 3;
                    }
                    if (radioButton9.Checked == true)
                    {
                        watchMovie = 4;
                    }
                    if (radioButton10.Checked == true)
                    {
                        watchMovie = 5;
                    }

                    //people who like to watch tv
                    if (radioButton11.Checked == true)
                    {
                        watchTV = 1;
                    }
                    if (radioButton12.Checked == true)
                    {
                        watchTV = 2;
                    }
                    if (radioButton13.Checked == true)
                    {
                        watchTV = 3;
                    }
                    if (radioButton14.Checked == true)
                    {
                        watchTV = 4;
                    }
                    if (radioButton15.Checked == true)
                    {
                        watchTV = 5;
                    }

                    //people who like to listen to radio
                    if (radioButton16.Checked == true)
                    {
                        listenRadio = 1;
                    }
                    if (radioButton17.Checked == true)
                    {
                        listenRadio = 2;
                    }
                    if (radioButton18.Checked == true)
                    {
                        listenRadio = 3;
                    }
                    if (radioButton19.Checked == true)
                    {
                        listenRadio = 4;
                    }
                    if (radioButton20.Checked == true)
                    {
                        listenRadio = 5;
                    }

                    //store activities rate to the timeConsumer table
                    activitiesTime = new SqlCommand("Insert into timeConsumer ( eat_out, movies,tv, radio ) values('" + eatOut + "','" + watchMovie + "','" + watchTV + "','" + listenRadio + "')", con);
                    activitiesTime.ExecuteNonQuery();

                    con.Close();
                    MessageBox.Show("Thank you for our time complete the survey");
                    clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
          
        }
        public void clear()
        {
            //clearing textboxes
            textSurname.Text = "";
            textName.Text = "";
            textNumber.Text = "";
            textDate.Text = "";
            textAge.Text = "";

            //Clearing checkBoxes
            checkBox1.Checked = false;
            checkBox2.Checked = false;
            checkBox3.Checked = false;
            checkBox4.Checked = false;
            checkBox5.Checked = false;
            checkBox6.Checked = false;

            //Clearing radioBoxes
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;
            radioButton5.Checked = false;
            radioButton6.Checked = false;
            radioButton7.Checked = false;
            radioButton8.Checked = false;
            radioButton9.Checked = false;
            radioButton10.Checked = false;
            radioButton11.Checked = false;
            radioButton12.Checked = false;
            radioButton13.Checked = false;
            radioButton14.Checked = false;
            radioButton15.Checked = false;
            radioButton16.Checked = false;
            radioButton17.Checked = false;
            radioButton18.Checked = false;
            radioButton19.Checked = false;
            radioButton20.Checked = false;


        }

    }
}
