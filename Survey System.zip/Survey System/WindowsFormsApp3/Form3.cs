﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp3
{
    public partial class Form3 : Form
    {
        Form1 homePage = new Form1();
        //string connection
        string path = @"Data Source = DESKTOP-TVCHB79\SQLEXPRESS;Initial Catalog = survey;Integrated Security=True";
        

        public Form3()
        {
            InitializeComponent();
            //display the total number of people
            int sumPeople = CalculateSumPeopleFromDatabase();
            label13.Text = sumPeople.ToString();

            //display the age average
            int ageAve = CalculateAgeAve();
            label19.Text = ageAve.ToString();

            //display the old person
            int oldPerson = determineOldPerson();
            label15.Text = oldPerson.ToString();

            //display the young person
            int youngPerson = determineYoungPerson();
            label14.Text = youngPerson.ToString();

            //display the perc pizza
            int pizzaPerc = percPizza();
            label17.Text = pizzaPerc.ToString();


            //display the perc pasta
            int pastaPerc = percPasta();
            label16.Text = pastaPerc.ToString();

            //display the perc pap and wors
            int papWorsPerc = percPapWors();
            label18.Text = papWorsPerc.ToString();


            //display eat out people
            int sumEatOut = howManyEat();
            label20.Text = sumEatOut.ToString();

            //display movie people
            int sumMovies = howManyWatchMovies();
            label21.Text = sumMovies.ToString();

            //display the TV people
            int sumTv = howManyWatchTv();
            label22.Text = sumTv.ToString();

            //display radio people
            int sumRadio = howManyRadio();
            label23.Text = sumRadio.ToString();
        }



        private int CalculateSumPeopleFromDatabase()
        {
            int sum = 0;

            using (SqlConnection connection = new SqlConnection(path))
            {
                connection.Open();
                string query = "SELECT COUNT(person_id) from person;";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    object result = command.ExecuteScalar();

                    if (result != null && result != DBNull.Value)
                    {
                        sum = Convert.ToInt32(result);
                    }
                }
                return sum;
            }
        }

        //calculating the age average
        private int CalculateAgeAve()
        {
            int ageAve = 0;

            using (SqlConnection connection = new SqlConnection(path))
            {
                connection.Open();
                string query = "select(SUM(person_Age)) / COUNT(person_Id) from person;";
 
                using (SqlCommand calcAve = new SqlCommand(query, connection))
                {
                    object aveResult = calcAve.ExecuteScalar();

                    if (aveResult != null && aveResult != DBNull.Value)
                    {
                        ageAve = Convert.ToInt32(aveResult);
                    }
                }
                return ageAve;
            }
        }


        //calculating the oldest person
        private int determineOldPerson()
        {
            int oldPerson = 0;

            using (SqlConnection connection = new SqlConnection(path))
            {
                connection.Open();
                string query = "select MAX(person_Age) from person;";

                using (SqlCommand personOld = new SqlCommand(query, connection))
                {
                    object oldResult = personOld.ExecuteScalar();

                    if (oldResult != null && oldResult != DBNull.Value)
                    {
                        oldPerson = Convert.ToInt32(oldResult);
                    }
                }
                return oldPerson;
            }
        }


        //calculating the youngest person
        private int determineYoungPerson()
        {
            int youngPerson = 0;

            using (SqlConnection connection = new SqlConnection(path))
            {
                connection.Open();
                string query = "select MIN(person_Age) from person;";

                using (SqlCommand personYoung = new SqlCommand(query, connection))
                {
                    object youngResult = personYoung.ExecuteScalar();

                    if (youngResult != null && youngResult != DBNull.Value)
                    {
                        youngPerson = Convert.ToInt32(youngResult);
                    }
                }
                return youngPerson;
            }
        }

        //calculating the percentage of people who like pizza 
        private int percPizza()
        {
            int pizzaPerc = 0;

            using (SqlConnection connection = new SqlConnection(path))
            {
                connection.Open();
                string query = " select ((COUNT(food_type1))/ (COUNT(food_id)))*100 from food Where food_type1 = 'Pizza'";


                using (SqlCommand pizza = new SqlCommand(query, connection))
                {
                    object pizzaResult = pizza.ExecuteScalar();

                    if (pizzaResult != null && pizzaResult != DBNull.Value)
                    {
                        pizzaPerc = Convert.ToInt32(pizzaResult);
                    }
                }
                return pizzaPerc;
            }
        }



        //calculating the percentage of people who like pasta 
        private int percPasta()
        {
            int pastaPerc = 0;

            using (SqlConnection connection = new SqlConnection(path))
            {
                connection.Open();
               string query = " select ((COUNT(food_type2)) / (COUNT(food_id)))*100 from food Where food_type2 = 'Pasta'";


                using (SqlCommand pasta = new SqlCommand(query, connection))
                {
                    object pastaResult = pasta.ExecuteScalar();

                    if (pastaResult != null && pastaResult != DBNull.Value)
                    {
                        pastaPerc = Convert.ToInt32(pastaResult);
                    }
                }
                return pastaPerc;
            }
        }


        //calculating the percentage of people who like pap and wors
        private int percPapWors()
        {
            int papWorsPerc = 0;

            using (SqlConnection connection = new SqlConnection(path))
            {
                connection.Open();
                string query = " select ((COUNT(food_type3))/ (COUNT(food_id)))*100 from food Where food_type3 = 'pap and wors'";


                using (SqlCommand papWors = new SqlCommand(query, connection))
                {
                    object papWorsResult = papWors.ExecuteScalar();

                    if (papWorsResult != null && papWorsResult != DBNull.Value)
                    {
                        papWorsPerc = Convert.ToInt32(papWorsResult);
                    }
                }
                return papWorsPerc;
            }
        }



        //eat out
        private int howManyEat()
        {
            int sumEatOut = 0;

            using (SqlConnection connection = new SqlConnection(path))
            {
                connection.Open();
                string query = "select SUM(eat_Out) / COUNT(activity_id) from timeConsumer ";


                using (SqlCommand eatOut = new SqlCommand(query, connection))
                {
                    object eatOutResult = eatOut.ExecuteScalar();

                    if (eatOutResult != null && eatOutResult != DBNull.Value)
                    {
                        sumEatOut = Convert.ToInt32(eatOutResult);
                    }
                }
                return sumEatOut;
            }
        }


        //watching movies
        private int howManyWatchMovies()
        {
            int sumMovies = 0;

            using (SqlConnection connection = new SqlConnection(path))
            {
                connection.Open();
                string query = "select SUM(movies) / COUNT(activity_id) from timeConsumer ";


                using (SqlCommand movies = new SqlCommand(query, connection))
                {
                    object moviesResult = movies.ExecuteScalar();

                    if (moviesResult != null && moviesResult != DBNull.Value)
                    {
                        sumMovies = Convert.ToInt32(moviesResult);
                    }
                }
                return sumMovies;
            }
        }


        //watching tv
        private int howManyWatchTv()
        {
            int sumTv = 0;

            using (SqlConnection connection = new SqlConnection(path))
            {
                connection.Open();
                string query = "select SUM(tv) / COUNT(activity_id) from timeConsumer ";


                using (SqlCommand tv = new SqlCommand(query, connection))
                {
                    object tvResult = tv.ExecuteScalar();

                    if (tvResult != null && tvResult != DBNull.Value)
                    {
                        sumTv = Convert.ToInt32(tvResult);
                    }
                }
                return sumTv;
            }
        }


        //radio
        private int howManyRadio()
        {
            int sumRadio = 0;

            using (SqlConnection connection = new SqlConnection(path))
            {
                connection.Open();
                string query = "select SUM(radio) / COUNT(activity_id) from timeConsumer ";


                using (SqlCommand radio = new SqlCommand(query, connection))
                {
                    object radioResult = radio.ExecuteScalar();

                    if (radioResult != null && radioResult != DBNull.Value)
                    {
                        sumRadio = Convert.ToInt32(radioResult);
                    }
                }
                return sumRadio;
            }
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            homePage.Show();
        }
    }
}
